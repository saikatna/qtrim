<?php include('functions/export_data.php'); ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Add talents</title>
  <!-- plugins:css -->
<?php include('includes/head_scripts.php'); ?>
<?php include('functions/conn.php'); ?>

</head>

<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <?php include('includes/header.php'); ?> 
	<!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
<?php include('includes/left.php'); ?>      
	  <!-- partial -->
      <div class="main-panel">        
                <div class="content-wrapper">
          <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">list talents</h4>
                  <p class="card-description">
				  <form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="post">					
				<button type="submit" id="export_data" name='export_data' value="Export to excel" class="btn btn-info"><i class="mdi mdi-format-vertical-align-bottom"></i></button>
			</form>
                  </p>
                  <div class="table-responsive pt-3">
                    <table class="table table-bordered">
                      <thead>
                        <tr>
                          <th>
                            #
                          </th>
                          <th>
                            Agency Name
                          </th>
                          <th>
                            Agency POC Name
                          </th>
                          <th>
                            Agency POC Email
                          </th>
						  <th>
                            designation
                          </th>
						  <th>
                            contact
                          </th>
                          <th>
                            Action
                          </th>
                        </tr>
                      </thead>
                      <tbody>
					  <?php
			$query=mysqli_query($conn,"select * from `talent_agency` order by id desc");
			while($row=mysqli_fetch_array($query)){
			?>
                        <tr>
                          <td>
                            <?php echo $row['id']; ?>
                          </td>
                          <td>
                            <?php echo $row['agency_name']; ?>
                          </td>
                          <td>
							<?php echo $row['poc_name']; ?>
                          </td>
                          <td>
                          <?php echo $row['email']; ?>
                          </td>
						  <td>
                          <?php echo $row['designation']; ?>
                          </td>
						  <td>
                          <?php echo $row['contact']; ?>
                          </td>
                          <td>
                            <a href="edit_talents.php?id=<?php echo $row['id']; ?>"><i class="mdi mdi-border-color"></i></a>
							<a href="functions/delete_talents.php?id=<?php echo $row['id']; ?>"><i class="mdi mdi-close-circle-outline"></i></a>
                          </td>
                        </tr>
			<?php } ?>
						
                     </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            </div>
        </div>
		<!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
		<?php include('includes/footer.php'); ?> 
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>

<?php include('includes/scripts.php'); ?> 

</body>

</html>
