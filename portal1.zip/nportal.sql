-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 04, 2022 at 06:13 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nportal`
--

-- --------------------------------------------------------

--
-- Table structure for table `talent_agency`
--

CREATE TABLE `talent_agency` (
  `id` int(11) NOT NULL,
  `agency_name` varchar(255) NOT NULL,
  `poc_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `e_template` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `modified` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `talent_agency`
--

INSERT INTO `talent_agency` (`id`, `agency_name`, `poc_name`, `email`, `designation`, `contact`, `e_template`, `created`, `modified`) VALUES
(24, 'saikat naskar', 'sa', 'saikat.naskar26@gmail.com', 'vc', '9883244717', 2, '2022-03-04 05:03:23', NULL),
(25, 'saikat', 'naskar', 'sa@gmail.com', 'eeee', '99323232', 0, '2022-03-04 05:04:02', NULL),
(26, 'prasoon', 'sonu', 'da@gmail.com', 'wewew', '78787887', 0, '2022-03-04 05:04:02', NULL),
(27, 'tito', 'ady', 'pa@gmail.com', 'trtrtrt', '54545455', 0, '2022-03-04 05:04:02', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `talent_agency`
--
ALTER TABLE `talent_agency`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `talent_agency`
--
ALTER TABLE `talent_agency`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
