<?php
	include('conn.php');
	if(isset($_REQUEST['id'])){
		//echo '<pre>';print_r($_POST);print_r($_FILES);exit;
		
		
		$id=$_REQUEST['id'];
		
		$res=mysqli_query($conn,"DELETE FROM `talent_agency` WHERE `talent_agency`.`id` = '$id'");
			if($res)
			{
				header('location:../list_talents.php?rdir=1');
			}
			else
			{
				header('location:../list_talents.php?rdir=2');
			}				
		
	}

?>