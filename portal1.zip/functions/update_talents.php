<?php
	include('conn.php');
	if(isset($_POST['add_tnt'])){
		//echo '<pre>';print_r($_POST);print_r($_FILES);exit;
		
			
		$agency_name=$_POST['agency_name'];
		$poc_name=$_POST['poc_name'];
		$email=$_POST['email'];
		$designation=$_POST['designation'];
		$contact=$_POST['contact'];
		$e_template=$_POST['e_template'];
		$id=$_POST['id'];
		
		$res=mysqli_query($conn,"UPDATE `talent_agency` SET `agency_name` = '$agency_name', `poc_name` = '$poc_name', `email` = '$email', `designation` = '$designation', `contact` = '$contact', `e_template` = '$e_template' WHERE `talent_agency`.`id` = '$id';");
			if($res)
			{
				header('location:../list_talents.php?rdir=1');
			}
			else
			{
				header('location:../list_talents.php?rdir=2');
			}				
		
	}

?>