<?php
	include('conn.php');
	if(isset($_POST['add_tnt'])){
		//echo '<pre>';print_r($_POST);print_r($_FILES);exit;
		
		if(!empty($_FILES['agency_list']['tmp_name']))
		{
		$file = $_FILES['agency_list']['tmp_name'];
          $handle = fopen($file, "r");
          $c = 0;
          $filesop = fgetcsv($handle, 1000, ",");
          //echo '<pre>';print_r($filesop);exit;
          while(($filesop = fgetcsv($handle, 1000, ",")) !== false)
                    {
                        //echo '<pre>';print_r($filesop);
           //echo $fname = $filesop[0].'<br>';
           //echo $lname = $filesop[1].'<br>';
           //echo $lname2 = $filesop[2].'<br>';
           //echo $lname4 = $filesop[3].'<br>';
           

			
				$agency_name=$filesop[0];
				$poc_name=$filesop[1];
				$email=$filesop[2];
				$designation=$filesop[3];
				$contact=$filesop[4];
				$e_template=$_POST['e_template'];
				
					mysqli_query($conn,"insert into `talent_agency` (agency_name, poc_name, email, designation,contact,e_template) values ('$agency_name', '$poc_name', '$email', '$designation', '$contact', '$e_template')");
		
			
					}
					header('location:../list_talents.php?rdir=4');
		
		}
		else
		{
			
		$agency_name=$_POST['agency_name'];
		$poc_name=$_POST['poc_name'];
		$email=$_POST['email'];
		$designation=$_POST['designation'];
		$contact=$_POST['contact'];
		$e_template=$_POST['e_template'];
		
		$res=mysqli_query($conn,"insert into `talent_agency` (agency_name, poc_name, email, designation,contact,e_template) values ('$agency_name', '$poc_name', '$email', '$designation', '$contact', '$e_template')");
			if($res)
			{
				header('location:../list_talents.php?rdir=1');
			}
			else
			{
				header('location:../list_talents.php?rdir=2');
			}				
		}
	}

?>