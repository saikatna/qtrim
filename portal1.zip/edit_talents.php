<?php
include('functions/conn.php');
$id=$_REQUEST['id'];  
$query=mysqli_query($conn,"select * from `talent_agency` where id='$id'");
$row=mysqli_fetch_array($query);
 ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <!--  meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Add talents</title>
  <!-- plugins:css -->
<?php include('includes/head_scripts.php'); ?>

</head>

<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <?php include('includes/header.php'); ?> 
	<!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
<?php include('includes/left.php'); ?>      
	  <!-- partial -->
      <div class="main-panel">        
        <div class="content-wrapper">
          <div class="row">
           <div class="col-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Add Talent Agency</h4>
                  <p class="card-description">
                    Add
                  </p>
                  <form class="forms-sample" enctype="multipart/form-data" method="post" action="functions/update_talents.php" name="frm1">
                    <div class="form-group">
                      <label for="exampleInputName1">Agency Name</label>
                      <input type="text" name="agency_name" class="form-control" id="exampleInputName1" value="<?php echo $row['agency_name']; ?>">
					  <input type="hidden" name="id" class="form-control" id="exampleInputName1" value="<?php echo $row['id']; ?>">
                    </div>
					<div class="form-group">
                      <label for="exampleInputName1">Agency POC Name</label>
                      <input type="text" name="poc_name" class="form-control" id="exampleInputName1"  value="<?php echo $row['poc_name']; ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail3">Agency POC Email</label>
                      <input type="email" name="email" class="form-control" id="exampleInputEmail3"  value="<?php echo $row['email']; ?>">
                    </div>
					<div class="form-group">
                      <label for="exampleInputEmail3">Designation</label>
                      <input type="text" name="designation" class="form-control" id="exampleInputEmail3"  value="<?php echo $row['designation']; ?>">
                    </div>
					<div class="form-group">
                      <label for="exampleInputEmail3">Contact Number.</label>
                      <input type="text" name="contact" class="form-control" id="exampleInputEmail3"  value="<?php echo $row['contact']; ?>">
                    </div>
					
                    
					<div class="form-group">
                      <label for="exampleInputEmail3">Select An Email Template.</label>
                      <select class="form-control" name="e_template" >
							  <option value="">Select</option>
                              <option value="1" <?php if($row['e_template']==1) { echo 'selected'; } ?>>Category1</option>
                              <option value="2" <?php if($row['e_template']==2) { echo 'selected'; } ?>>Category2</option>
                            </select>
                    </div>
                    
                    <button type="submit" class="btn btn-primary me-2" name="add_tnt" value="add_tnt">Send Invite</button>
                    <button class="btn btn-light">Cancel</button>
                  </form>
                </div>
              </div>
            </div>
            </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
		<?php include('includes/footer.php'); ?> 
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>

<?php include('includes/scripts.php'); ?> 

</body>

</html>
